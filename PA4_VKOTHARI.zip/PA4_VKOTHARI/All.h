/*
 * All.h
 *
 *  Created on: Sep 26, 2018
 *      Author: student
 */

#ifndef ALL_H_
#define ALL_H_

extern int WorldS ;
extern int BIRTH_ANTS;
extern int BABYDOODLE;



#endif /* ALL_H_ */
