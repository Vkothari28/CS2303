README.txt

The purpose of this program is to create a
2D similation of predator and the prey
The ants are the prey and the predator is doodlebug
The predator has to eat in 3 turns or else it dies
Predators can move in any director and so can prey
Prey and predators can also BREED

The program works by having an initial amount of anrs and doodlegs
The program plays a certain number generations and returns the grid.
